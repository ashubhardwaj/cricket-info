package com.example.cricketinfo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CricketInfoApplication {
    public static void main(String[] args) {
        SpringApplication.run(CricketInfoApplication.class, args);
    }
}
